"""Serialize THIS CHAT'S AI review, not rule predictions or human reference labels.

The twelve judgments below were written by the conversational AI after reading the
saved request inputs and their primary-source excerpts. Python only extracts exact
continuous quotations, validates the existing import protocol, and packages files.
No model API, assess/assess_all, SFT/GRPO checkpoint, or human-review route is called.
"""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,sys,zipfile

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent.parent
sys.path.insert(0,(OUT/'runtime-location.txt').read_text(encoding='utf-8'))
import ai_prereview as ai

def read(path):return json.loads(path.read_text(encoding='utf-8'))
def write(path,value):
    if path.exists():raise RuntimeError('Preserve existing artifact: '+str(path))
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def quote(cid,pid,reason,start=None,end=None,before=None):
    p=next(p for p in REQUESTS[cid]['input']['evidence'] if p['id']==pid)
    value=p['text'];a=value.index(start) if start else 0
    b=value.index(end,a)+len(end) if end else value.index(before,a) if before else len(value)
    return {'passage_id':pid,'quote':value[a:b],'reason':reason}

REQUESTS={p.stem:read(p) for p in sorted((OUT/'requests').glob('ai-dev-*.json'))}
assert len(REQUESTS)==12
BEFORE=read(OUT/'protected-before.json')
assert all(sha(ROOT/path)==value for path,value in BEFORE.items()), 'Protected source changed; stop.'
FIRST='living-guide-2024-p2'
PAYMENT_START='连续参保满 6 个月（不'
PAYMENT_END='发放第二笔补贴。'
DATE_LIMIT='只对给定资料快照预审；现行效力与完整资格尚未人工核验。'
RENT_LIMIT='租房片段来自2026-10-30页面取证，晚于本例2026-10-21申请参考日；取证日不是生效日，不能据此倒推申请日适用效力。'

# Actual AI-authored analysis for the separate development cases.
REVIEWS={
 'ai-dev-01':{
  'judgment':'needs_info',
  'summary':'已填写毕业日期2025-05-13，但毕业记录精度仍为unknown；表单里出现具体日期不等于原记录确实记载该日。原文区分明确到日与仅记年月的认定口径，需核实学信网记录后再确认申请时限。该缺口本身不证明不满足，也不能据此认定完整资格满足。参保起算月为2025-07、已填有效连续月数为13，应以逐月有效记录核对，不把日历跨度直接补成参保月数。'+DATE_LIMIT,
  'missing_fields':['extra.graduation_record_precision'],
  'next_questions':['学信网毕业记录明确到具体日期，还是仅载明年月？请据原记录确认，勿自行补日。','若仅记年月，按所存指南认定后的毕业日期是什么？请确认后重新核对期限。','2025-07起算与已填13个有效连续月数分别依据哪些完整月份？是否有不计入或起算月填错的情况？'],
  'citations':[
   quote('ai-dev-01','living-guide-2024-p3','此处说明国内学历采用学信网载明的毕业时间；下一页为同一段的日期精度续文，需联读原版。','2.毕业时间认定。','学信网或'),
   quote('ai-dev-01','living-guide-2024-p4','上一页末尾与本页续文共同说明仅记年月时采用月末；不能把表单具体日当作原记录精度证明。','教育部留学服务中心学历学位认证书上载明具体年月日的，','毕业时间以当月最后一天认定。')]
 },
 'ai-dev-02':{
  'judgment':'manual_check',
  'summary':'计入参保时长的经历中有劳务派遣或人力资源单位经历。该经历不是原文中的自动排除项，但需要当前实际用工单位核实历史实际用工单位及其资格，并核对申报渠道；不能仅因employer_qualified=true或已填12个月就跳过这一步。所填月份已超过首笔6个月的数量门槛，仍不代表参保有效性及完整资格已验证。'+DATE_LIMIT,
  'missing_fields':[],
  'next_questions':['当前实际用工单位是否已核实计入连续参保期间的全部历史实际用工单位及其资格？无需在本演示页填写单位识别号码。','是否按所存指南的派遣经历渠道，由单位通过亲清在线申报并准备相关合同备查？','2025-07起算与已填12个有效连续月数如何对应？是否存在不合格单位月份、断缴或起算月需要重算？'],
  'citations':[
   quote('ai-dev-02','living-guide-2024-p4','原文对派遣及人力资源单位经历要求另核实历史实际用工信息，并非一概排除。','计入连续参保时长期间有劳务派遣经历','单位核实并填写其实际历史用工单位、统一社会信用代码。'),
   quote('ai-dev-02','living-guide-2024-p6','此处明确有关经历须由单位通过亲清在线申报；不能直接套用普通个人入口。','当前属于劳务派遣人员','的人员，均需由单位通过亲清在线申报。'),
   quote('ai-dev-02',FIRST,'这里只支持首笔与第二笔的月份门槛，不认证申报的12个月是否真实有效。',PAYMENT_START,PAYMENT_END)]
 },
 'ai-dev-03':{
  'judgment':'needs_info',
  'summary':'当前合格杭州单位参保状态和已完成的有效连续参保月数均未填写，无法核对首笔的连续参保数量及申请时在保要求。起算月2025-07与就业、单位资格等已填项不能替代这两项事实；未知必须保留，不能自动推算为15个月或视为当前在保。'+DATE_LIMIT,
  'missing_fields':['insurance_current','insurance_months'],
  'next_questions':['在本例申请参考日2026-10-21，是否仍在符合条件的杭州单位参加社保？','截至该参考日，已完成且不含补缴的有效连续参保月份具体有多少？请依据逐月记录核对。','逐月记录是否支持毕业后首月及达到连续6个月的期限要求？如中途断缴或单位不合格，应重新核对有效起算月。'],
  'citations':[
   quote('ai-dev-03',FIRST,'此段说明首笔要求连续满6个月且不含补缴，不能以空值或日历跨度替代。',PAYMENT_START,PAYMENT_END),
   quote('ai-dev-03','living-guide-2024-p3','此条直接要求申请时在合格杭州单位参保；已在杭就业不等同于该项已核实。','4.申请时需在符合条件的杭州用人单位参加社保。','5.毕业前（不含毕业当月）参保时间不得计入连续参保时长。')]
 },
 'ai-dev-04':{
  'judgment':'manual_check',
  'summary':'本例为国境外学历，超出现有项目自动核对国内学历的覆盖口径，应转人工核实认证。原文并未一概排除境外学历，而是另有留服认证及认证书毕业时间等要求；不能把自动覆盖不足写成政策不符合。当前结构没有可证明认证有效性、认证结果与毕业时间一致的字段，所以missing_fields留空不代表材料齐全。已填11个月也需逐月核对。'+DATE_LIMIT,
  'missing_fields':[],
  'next_questions':['是否具有可核验、对应本次学历学位的教育部留服中心认证结果？无需在本网页填写认证书编号。','认证书载明的毕业日期及精度是否与本例2025-05-13及day一致？','请人工对照原版表格，确认中国国籍及境外学历对应的申请时限、参保列和申报信息，避免跨列表格错读。'],
  'citations':[
   quote('ai-dev-04',FIRST,'原文列明境外学历学位的认证要求，不能据境外属性直接作不满足结论。','国（境）外高校毕业生学历学位需经国家教育部留服中心认证','国（境）外高校毕业生学历学位需经国家教育部留服中心认证'),
   quote('ai-dev-04','living-guide-2024-p4','此处额外要求认证书信息；当前人物字段未覆盖其真实性及对应关系。','其中国（境）外高校毕业生还需填写','务中心国（境）外学历学位认证书编号。'),
   quote('ai-dev-04','living-guide-2024-p3','此段说明境外学历采用认证书载明的毕业时间；不能直接用未核验的表单日期替代。','2.毕业时间认定。','学信网或')]
 },
 'ai-dev-05':{
  'judgment':'listed_block',
  'summary':'按已填写的10个有效连续参保月数，尚未达到给定指南的第二笔12个月数量条件；这已是当前所列限制，不能只因标题强调“首笔状态未知”而遗漏。首笔领取状态另需核实，但未知不应被自动填成已领取。应先核对逐月记录及同一学历申领记录，不能用2025-07至申请日的日历跨度覆盖已报10个月。该判断仅限填报事实与给定快照，不是正式驳回。'+DATE_LIMIT,
  'missing_fields':['first_installment_received'],
  'next_questions':['本次学历首笔是否已经审核发放？请核对对应同一学历及同一待遇记录，而非仅凭记忆。','截至参考日究竟有多少已完成且不含补缴的有效连续参保月份？若确为10个月，需待满足原文要求后再核对第二笔。','起算月2025-07与已报10个月存在的跨度差异，是否来自断缴、不合格月份、记录漏填或起算月填错？'],
  'citations':[
   quote('ai-dev-05',FIRST,'第二笔明确为连续参保满12个月且不含补缴；已报10个月未达数量门槛。',PAYMENT_START,PAYMENT_END),
   quote('ai-dev-05','living-guide-2024-p5','此段说明第二笔通常系统比对发放，不能把首笔状态未知当成第二笔已经符合或已自动发放。','第一笔补贴需主动申请','系统自动比对审核通过后，向申请人\n的银行卡拨付生活补贴资金。')]
 },
 'ai-dev-06':{
  'judgment':'listed_block',
  'summary':'已填第二笔对应的有效连续参保时长只有9个月，按给定指南未达12个月；同时当前是否在合格杭州单位参保仍为未知。已经领取首笔不证明第二笔月份已足、当前在保或全部资格已满足。应按实际逐月记录核对这两项，保留未知状态。该判断仅发现当前所填事实中的限制，不作正式审批结论。'+DATE_LIMIT,
  'missing_fields':['insurance_current'],
  'next_questions':['申请参考日是否仍在符合条件的杭州单位参加社保？','已填9个月是否为截至参考日、剔除补缴后的完整有效连续时长？若确为9个月，尚不能认定达到第二笔门槛。','请核对2025-07起算与已报9个月的差异，确认是否有断缴、不合格月份或起算月填错。'],
  'citations':[
   quote('ai-dev-06',FIRST,'此段直接支持第二笔12个月的数量要求；首笔已领取不能替代该要求。',PAYMENT_START,PAYMENT_END),
   quote('ai-dev-06','living-guide-2024-p3','此条另外要求申请时在合格杭州单位参保，当前未知必须补核。','4.申请时需在符合条件的杭州用人单位参加社保。','4.申请时需在符合条件的杭州用人单位参加社保。')]
 },
 'ai-dev-07':{
  'judgment':'listed_block',
  'summary':'本例同时申报曾以其他学历享受生活补贴、本次学历首笔已领，以及当前有效连续参保8个月。给定原文对已享受后再获学历的情形列有排除说明，第二笔的12个月数量条件也尚未达到。需核实历史待遇与本次学历时间线，识别是否为重复申领或字段理解混淆；不能因本次首笔填“已领”而忽略这些限制，也不能直接推断原发放记录有误。'+DATE_LIMIT,
  'missing_fields':[],
  'next_questions':['此前享受生活补贴对应哪次学历，与本次学历取得及本次首笔发放的先后关系是什么？无需提供个人身份号码。','所填“其他学历曾享受”和“本次首笔已领”是否指同一政策、不同学历？请核对待遇记录及字段理解。','截至参考日是否确为8个有效连续参保月？请依据逐月记录解释与2025-07起算的跨度差异。'],
  'citations':[
   quote('ai-dev-07','living-guide-2024-p4','此项排除说明需结合领取与取得学历的先后关系核验；不能仅凭本次首笔状态跳过。','3.已享受应届毕业生生活补贴的申请人再次获得普通高','生生活补贴范畴。'),
   quote('ai-dev-07','living-guide-2024-p9','该问答进一步说明学历升级不产生再次申领的一般机会；仍需核对本例实际待遇对应关系。','申请人只能享受一次应届毕业生生活补贴','领，学历升级也无法再次申请。'),
   quote('ai-dev-07',FIRST,'除历史领取限制外，已报8个月仍未达到第二笔12个月数量条件。',PAYMENT_START,PAYMENT_END)]
 },
 'ai-dev-08':{
  'judgment':'listed_block',
  'summary':'已填第二笔有效连续参保时长7个月，尚未达到原文12个月要求；“连续时长是否不含补缴”又未确认，不能把未知视为已经剔除。即使全部7个月都有效，按所填数量仍不足12个月；若其中含补缴，还需重新计算有效时长。首笔已领不替代第二笔条件。'+DATE_LIMIT,
  'missing_fields':['insurance_without_backpay'],
  'next_questions':['已报7个月是否全部不含补缴？请逐月识别补缴、断缴和不合格单位月份，不要把未知默认成“是”。','截至2026-10-21，剔除不计入月份后，符合原文口径的有效连续月数及首月分别是什么？','若核实后仍为7个月，先按原文处理未达第二笔12个月门槛的问题，再核对其他资格。'],
  'citations':[
   quote('ai-dev-08',FIRST,'此段同时包含第二笔12个月和不含补缴两项要求，已报7个月及补缴口径未知均不能略过。',PAYMENT_START,PAYMENT_END),
   quote('ai-dev-08','living-guide-2024-p3','毕业前非毕业当月的月份不能直接计入，核对有效连续时长还须注意该口径。','5.毕业前（不含毕业当月）参保时间不得计入连续参保时长。','5.毕业前（不含毕业当月）参保时间不得计入连续参保时长。')]
 },
 'ai-dev-09':{
  'judgment':'needs_info',
  'summary':'家庭核验是否覆盖申请人、配偶及未成年子女尚未确认，因此family_has_home=false不能证明符合给定快照的申请家庭无房口径。应先确认核验范围，再核对相关地域内住宅、非住宅、交易历史及家庭住房优惠。已填6个月参保不等于全部条件满足，本次检索也未提供参保期限细则。'+RENT_LIMIT,
  'missing_fields':['extra.family_scope_confirmed'],
  'next_questions':['“无房”的核验是否包含申请人、配偶及未成年子女，而不只是申请人本人？','按已选用人单位地域口径，以上全部家庭成员的住宅、非住宅及房产交易历史是否均已核对？','家庭曾享受的住房优惠是否已按完整范围核对？请补查参保期限及申请参考日适用的原始版本。'],
  'citations':[
   quote('ai-dev-09','rent-platform-2026-l40','此定义直接说明申请家庭包含哪些成员，不能以本人名下无房替代家庭核验。','“申请家庭”包括申请人、配偶及未成年子女。','“申请家庭”包括申请人、配偶及未成年子女。'),
   quote('ai-dev-09','rent-platform-2026-l40','相关住房优惠也按家庭范围解释，核验不能只覆盖申请人。','新引进应届大学生“未享受租房优惠政策”指'),
   quote('ai-dev-09','rent-platform-2026-l80','原文描述通过共享数据核验相关信息；本页面自填值不等于已通过官方比对。','其他所需学历、社保、房产及租房优惠政策信息','需按规定提供复核材料。')]
 },
 'ai-dev-10':{
  'judgment':'listed_block',
  'summary':'本例已填家庭范围与地域口径已核对，但相应口径下存在房产交易历史。给定快照的“无房”不仅要求当前无房产，还要求无买卖、赠与、继承等交易记录，所以不能因family_has_home=false而忽略该项限制。应人工核实历史记录归属、类型及政策适用时间。另已填5个月参保，项目整理规则提示参保问题，但本次检索未提供原始期限条文，不能把整理规则当作原文佐证。'+RENT_LIMIT,
  'missing_fields':[],
  'next_questions':['已确认的历史交易具体属于申请家庭成员及相应地域口径吗，类型为买卖、赠与、继承还是其他记录？无需填写房屋地址或个人证件号码。','能否由受理系统或主管部门核实该历史记录在本例申请时点的适用处理？当前无房并不自动消除历史问题。','请补检原始参保期限条文，并核对5个有效连续月份及2025-07起算记录；不要仅据整理规则作完整资格结论。'],
  'citations':[
   quote('ai-dev-10','rent-platform-2026-l40','此段在两类地域口径下均列明无房产及无交易记录；当前无房与无交易历史是不同要求。','新引进应届大学生“无房”指',before='新引进应届大学生“未享受租房优惠政策”'),
   quote('ai-dev-10','rent-platform-2026-l26','此段说明相关数据及异议审核职责，支持应核实记录的流程，不证明本例记录已被确认。','（4）各区、县（市）相关职能部门')]
 },
 'ai-dev-11':{
  'judgment':'manual_check',
  'summary':'已填曾享受租房补贴后再次取得学历，且rent_first_received=false。后者不能证明此前从未享受该待遇，需要核对字段所指批次与学历时间线。本次检索主要返回一般对象、非全日制及发放方式，未给出“既往领取后再获学历”专门条款，不能仅凭字段名或项目整理规则直接判符合或不符合。所填参保4个月也需补检原始期限条文。'+RENT_LIMIT,
  'missing_fields':[],
  'next_questions':['以前享受的租房补贴是否为同一政策待遇，领取与本次学历取得的先后关系是什么？','rent_first_received=false指当前申请批次未领首笔，还是历史上从未领过？请与“曾享受后再获学历”字段核对。','请补检完整原始细则中再次取得学历、重复申领及连续参保期限的条款，并核实2026-10-21适用的版本；不要用一般对象段落替代专门条款。'],
  'citations':[
   quote('ai-dev-11','rent-platform-2026-l48','此段只提供一般对象、就业、家庭无房及住房优惠条件，不能单独证明再获学历后的重复申领规则。'),
   quote('ai-dev-11','rent-platform-2026-l70','有效申请要求当时已符合条件，不能在缺少专门条款及历史记录核对时推定已满足。')]
 },
 'ai-dev-12':{
  'judgment':'needs_info',
  'summary':'住房核验是否按用人单位所在地域口径执行尚未确认。给定快照区分主城区等范围与西部区县范围，并包含住宅、非住宅及交易历史；不能只查任意一个区或本人名下住房后推定满足。已填3个月参保，需补检原始期限条文并逐月核对；当前返回片段未包含该门槛，不能用整理规则代替原文。'+RENT_LIMIT,
  'missing_fields':['extra.housing_scope_confirmed'],
  'next_questions':['用人单位属于哪一行政区县，应按所存细则采用跨主城区等范围，还是用人单位所在西部区县范围？无需提供单位名称或具体地址。','申请人、配偶及未成年子女的住宅、非住宅及交易历史，是否都按上述完整地域口径核验？','请补检适用申请时点的原始参保期限条款，并核实已报3个月与2025-07起算记录之间的差异。'],
  'citations':[
   quote('ai-dev-12','rent-platform-2026-l40','本段明确区分两类住房地域范围及房产类型、交易记录，不能把任意局部查询等同于已按政策范围核验。','“申请家庭”包括',before='新引进应届大学生“未享受租房优惠政策”'),
   quote('ai-dev-12','rent-platform-2026-l8','此句只说明无房及住房优惠等一般对象条件，不能替代完整地域解释或尚未检得的参保期限条款。',end='发放租房补贴。')]
 }
}

now=datetime.now(timezone.utc).isoformat(timespec='seconds')
MODEL='Codex · 本次对话AI预审（非项目Base/SFT/GRPO）'
rows=[];(OUT/'responses').mkdir(exist_ok=True)
for cid,value in REVIEWS.items():
    req=REQUESTS[cid]
    assert req==ai.request(cid), 'Saved request differs from current browser protocol.'
    response={'protocol':ai.PROTOCOL,'case_id':cid,'request_sha256':req['request_sha256'],'result':value}
    row=ai.import_response({'case_id':cid,'response':response,'model':{'name':MODEL,'source':'user_declared_external_model','generated_at':now},'imported_at':now})
    assert row['human_check'] is None and all(c['found'] and c['quote_matches'] for c in row['citation_checks'])
    write(OUT/'responses'/f'{cid}.json',response);rows.append(row)

packet=ai.packet({'records':rows,'saved_at':now})
assert ai.restore({'packet':packet})==packet and len(packet['records'])==12
assert {r['case_id'] for r in rows}==set(REQUESTS)
name='惠才通-12条AI预审-可导入.json'
write(OUT/name,packet)
after={path:sha(ROOT/path) for path in BEFORE}
assert after==BEFORE, 'Protected content changed; stop.'
write(OUT/'protected-after.json',after)
audit={'created_at':now,'protocol':ai.PROTOCOL,'source_application_version':'0.8.2-online','batch_sha256':packet['batch_sha256'],'packet_sha256':packet['sha256'],'file_sha256':sha(OUT/name),'records':12,'all_human_check_null':True,'independent_human_reference':False,'purpose':'development_only','judgments':dict(Counter(r['response']['result']['judgment'] for r in rows)),'citations':sum(len(r['citation_checks']) for r in rows),'citations_with_exact_text_match':sum(c['quote_matches'] for r in rows for c in r['citation_checks']),'source_checked_on':'2026-10-30','application_reference_date':'2026-10-21','generation_method':'Actual AI analysis authored in this Codex conversation from the 12 saved request inputs and their retrieved excerpts. Python only preserves exact source quotations, serializes, validates and packages these responses. No rule-prediction function generated these judgments.','model_identity':MODEL,'exact_model_id_independently_verified':False,'additional_model_api_calls':0,'project_base_sft_grpo_models_used':False,'human_reference_labels_generated':0,'held_out_60_used_as_ai_input':False,'reserved_sources_and_human_materials_unchanged':after==BEFORE,'imported_at_meaning':'Local validation and serialization time, not an assertion that the user has imported the file into the website.','verification_limits':['Quote membership is a mechanical check, not a human confirmation of entailment.','No accuracy is computed without independent human reference labels.','Rent excerpts were captured after the case application reference date; applicability at that earlier date is not established.','Some rent retrievals omit the specific prior-benefit/reacquired-degree or insurance duration clauses.','A saved_at/request hash binds this artifact to the current development protocol and snapshots; it is not a signature verifying author/model identity.']}
write(OUT/'audit.json',audit)
lines=['惠才通：12条开发案例 AI预审结果','生成方式：本次Codex对话中的AI逐条分析；非规则程序答案，非本地Base/SFT/GRPO实验。','状态：全部为AI建议、未人工核查。独立人工参考答案为0条。','资料：现有v0.8.2原文快照；未重新核验当前效力。','','导入方法：','1. 打开 https://huicaitong-hangzhou.zishu41.chatgpt.site/#review-ai','2. 点击顶部“导入AI辅助记录”，选择“'+name+'”。','3. 页面应显示12条已有AI建议、0条最新记录含人工核查、12个历史版本（在空白工作台中）。','4. 在“开发案例”选择器逐条查看；需要进一步核查时再由人阅读原文并记录，不能把AI预审改写成独立人工答案。','此文件是整批记录，请用“导入AI辅助记录”，不要用单条“从JSON文件导入回答”。responses目录为单条回答备用。','已有记录会合并保留，记录数量可能超过12；重复导入相同记录不应增加版本。','','本轮AI发现（待人工复核）：','- 05—08按所填参保月数分别为10、9、8、7个月，未达到给定生活补贴指南第二笔12个月条件；不能只看案例标题中的另一处缺失。','- 07还需核对其他学历已享受与本次首笔已领取的待遇/学历时间线。','- 09—12的租房检索片段缺少部分连续参保期限原文，11另缺再获学历/既往领取专门条款。没有这些依据时不把字段名或项目整理规则当作原文。','- 租房页面取证日2026-10-30晚于案例申请日2026-10-21，不能据取证日期倒推生效日期。','- 共同参保起算月为2025-07，但已报月数较短或未知；须核对逐月有效记录，不能把日历跨度直接补成参保完成月数。','- 这12条本来集中设置了核验问题，本轮没有给出“可能满足”不代表模型总体准确率或政策服务通过率。','','逐条摘要：']
for row in rows:
    cid=row['case_id'];r=row['response']['result'];c=REQUESTS[cid]['input']['case']
    lines+=['',cid+' '+c['title']+' —— '+ai.JUDGMENTS[r['judgment']],r['summary'],'待补字段：'+('、'.join(ai.fields()[k] for k in r['missing_fields']) or '无结构化空值；不代表证据齐全或资格满足。'),'AI建议追问：']
    lines += [f'{i}. {q}' for i,q in enumerate(r['next_questions'],1)]
    lines += ['引用定位：'+'、'.join(x['passage_id'] for x in r['citations'])]
lines+=['','真实性及边界：模型名称指本次对话AI，未独立认证具体型号；未调用项目本地模型或另发模型API请求。AI核对引文也不是人工核查。imported_at为本地校验封装时间。60条保留案例、A/B材料和独立协议均未改动。']
(OUT/'导入说明与预审摘要.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
bundle=OUT/'惠才通-12条AI预审-完整包.zip'
with zipfile.ZipFile(bundle,'x',zipfile.ZIP_DEFLATED) as z:
    for path in [OUT/name,OUT/'audit.json',OUT/'导入说明与预审摘要.txt',OUT/'evidence-snapshot.json',OUT/'protected-before.json',OUT/'protected-after.json',OUT/'assemble-results.py',*sorted((OUT/'requests').glob('*.json')),*sorted((OUT/'responses').glob('*.json'))]:z.write(path,path.relative_to(OUT).as_posix())
print(json.dumps({'import_file':str(OUT/name),'bytes':(OUT/name).stat().st_size,'packet_sha256':packet['sha256'],'judgments':audit['judgments'],'citations':audit['citations'],'all_quotes_match':audit['citations']==audit['citations_with_exact_text_match'],'reserved_unchanged':after==BEFORE,'bundle':str(bundle)},ensure_ascii=False,indent=2))
